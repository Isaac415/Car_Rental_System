﻿namespace Car_Rental_System
{
    partial class car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.VINbox = new System.Windows.Forms.TextBox();
            this.NoOfSeatsbox = new System.Windows.Forms.TextBox();
            this.yearbox = new System.Windows.Forms.TextBox();
            this.colourbox = new System.Windows.Forms.TextBox();
            this.insurancenobox = new System.Windows.Forms.TextBox();
            this.odometerNumberbox = new System.Windows.Forms.TextBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.modifyButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.makebox = new System.Windows.Forms.TextBox();
            this.modelbox = new System.Windows.Forms.TextBox();
            this.carTypeIDbox = new System.Windows.Forms.TextBox();
            this.branchIDbox = new System.Windows.Forms.TextBox();
            this.display = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.display)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "VIN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Make";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(12, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Model";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(12, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(12, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "No Of Seats";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(12, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 21);
            this.label6.TabIndex = 5;
            this.label6.Text = "Colour";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(12, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 21);
            this.label7.TabIndex = 6;
            this.label7.Text = "Insurance No";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(12, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 21);
            this.label8.TabIndex = 7;
            this.label8.Text = "Odometer Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(12, 313);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 21);
            this.label9.TabIndex = 8;
            this.label9.Text = "Branch ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(12, 348);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 21);
            this.label10.TabIndex = 9;
            this.label10.Text = "Car Type ID";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // VINbox
            // 
            this.VINbox.Location = new System.Drawing.Point(194, 12);
            this.VINbox.Name = "VINbox";
            this.VINbox.Size = new System.Drawing.Size(194, 23);
            this.VINbox.TabIndex = 10;
            // 
            // NoOfSeatsbox
            // 
            this.NoOfSeatsbox.Location = new System.Drawing.Point(194, 157);
            this.NoOfSeatsbox.Name = "NoOfSeatsbox";
            this.NoOfSeatsbox.Size = new System.Drawing.Size(194, 23);
            this.NoOfSeatsbox.TabIndex = 11;
            // 
            // yearbox
            // 
            this.yearbox.Location = new System.Drawing.Point(194, 119);
            this.yearbox.Name = "yearbox";
            this.yearbox.Size = new System.Drawing.Size(194, 23);
            this.yearbox.TabIndex = 12;
            // 
            // colourbox
            // 
            this.colourbox.Location = new System.Drawing.Point(194, 197);
            this.colourbox.Name = "colourbox";
            this.colourbox.Size = new System.Drawing.Size(194, 23);
            this.colourbox.TabIndex = 13;
            // 
            // insurancenobox
            // 
            this.insurancenobox.Location = new System.Drawing.Point(194, 239);
            this.insurancenobox.Name = "insurancenobox";
            this.insurancenobox.Size = new System.Drawing.Size(194, 23);
            this.insurancenobox.TabIndex = 14;
            // 
            // odometerNumberbox
            // 
            this.odometerNumberbox.Location = new System.Drawing.Point(194, 276);
            this.odometerNumberbox.Name = "odometerNumberbox";
            this.odometerNumberbox.Size = new System.Drawing.Size(194, 23);
            this.odometerNumberbox.TabIndex = 15;
            // 
            // AddButton
            // 
            this.AddButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddButton.Location = new System.Drawing.Point(194, 388);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(194, 38);
            this.AddButton.TabIndex = 21;
            this.AddButton.Text = "Add Car";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // modifyButton
            // 
            this.modifyButton.Location = new System.Drawing.Point(194, 432);
            this.modifyButton.Name = "modifyButton";
            this.modifyButton.Size = new System.Drawing.Size(194, 38);
            this.modifyButton.TabIndex = 22;
            this.modifyButton.Text = "Modify Car";
            this.modifyButton.UseVisualStyleBackColor = true;
            this.modifyButton.Click += new System.EventHandler(this.modifyButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(194, 476);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(194, 38);
            this.deleteButton.TabIndex = 23;
            this.deleteButton.Text = "Delete Car";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // makebox
            // 
            this.makebox.Location = new System.Drawing.Point(194, 46);
            this.makebox.Name = "makebox";
            this.makebox.Size = new System.Drawing.Size(194, 23);
            this.makebox.TabIndex = 24;
            // 
            // modelbox
            // 
            this.modelbox.Location = new System.Drawing.Point(194, 81);
            this.modelbox.Name = "modelbox";
            this.modelbox.Size = new System.Drawing.Size(194, 23);
            this.modelbox.TabIndex = 25;
            // 
            // carTypeIDbox
            // 
            this.carTypeIDbox.Location = new System.Drawing.Point(194, 350);
            this.carTypeIDbox.Name = "carTypeIDbox";
            this.carTypeIDbox.Size = new System.Drawing.Size(194, 23);
            this.carTypeIDbox.TabIndex = 26;
            // 
            // branchIDbox
            // 
            this.branchIDbox.Location = new System.Drawing.Point(194, 315);
            this.branchIDbox.Name = "branchIDbox";
            this.branchIDbox.Size = new System.Drawing.Size(194, 23);
            this.branchIDbox.TabIndex = 27;
            // 
            // display
            // 
            this.display.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.display.Location = new System.Drawing.Point(405, 12);
            this.display.Name = "display";
            this.display.RowTemplate.Height = 25;
            this.display.Size = new System.Drawing.Size(705, 514);
            this.display.TabIndex = 28;
            // 
            // car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 538);
            this.Controls.Add(this.display);
            this.Controls.Add(this.branchIDbox);
            this.Controls.Add(this.carTypeIDbox);
            this.Controls.Add(this.modelbox);
            this.Controls.Add(this.makebox);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.modifyButton);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.odometerNumberbox);
            this.Controls.Add(this.insurancenobox);
            this.Controls.Add(this.colourbox);
            this.Controls.Add(this.yearbox);
            this.Controls.Add(this.NoOfSeatsbox);
            this.Controls.Add(this.VINbox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "car";
            this.Text = "Car (Staff)";
            this.Load += new System.EventHandler(this.car_Load);
            ((System.ComponentModel.ISupportInitialize)(this.display)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox VINbox;
        private TextBox NoOfSeatsbox;
        private TextBox yearbox;
        private TextBox colourbox;
        private TextBox insurancenobox;
        private TextBox odometerNumberbox;
        private Button AddButton;
        private Button modifyButton;
        private Button deleteButton;
        private TextBox makebox;
        private TextBox modelbox;
        private TextBox carTypeIDbox;
        private TextBox branchIDbox;
        private DataGridView display;
    }
}