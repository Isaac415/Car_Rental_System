﻿namespace Car_Rental_System
{
    partial class branch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Branch_ID = new System.Windows.Forms.Label();
            this.Description = new System.Windows.Forms.Label();
            this.Street_Address_1 = new System.Windows.Forms.Label();
            this.Street_Address_2 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.Label();
            this.Province = new System.Windows.Forms.Label();
            this.Postal_Code = new System.Windows.Forms.Label();
            this.Phone_Num = new System.Windows.Forms.Label();
            this.Streetaddress1box = new System.Windows.Forms.TextBox();
            this.Streetaddress2box = new System.Windows.Forms.TextBox();
            this.postalCodebox = new System.Windows.Forms.TextBox();
            this.provincebox = new System.Windows.Forms.TextBox();
            this.Citybox = new System.Windows.Forms.TextBox();
            this.phonenumberbox = new System.Windows.Forms.TextBox();
            this.Add_Branch = new System.Windows.Forms.Button();
            this.Modify_Branch = new System.Windows.Forms.Button();
            this.Delete_Branch = new System.Windows.Forms.Button();
            this.Descriptionbox = new System.Windows.Forms.TextBox();
            this.BranchIDbox = new System.Windows.Forms.TextBox();
            this.display = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.display)).BeginInit();
            this.SuspendLayout();
            // 
            // Branch_ID
            // 
            this.Branch_ID.AutoSize = true;
            this.Branch_ID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Branch_ID.Location = new System.Drawing.Point(8, 11);
            this.Branch_ID.Name = "Branch_ID";
            this.Branch_ID.Size = new System.Drawing.Size(77, 21);
            this.Branch_ID.TabIndex = 0;
            this.Branch_ID.Text = "Branch ID";
            // 
            // Description
            // 
            this.Description.AutoSize = true;
            this.Description.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Description.Location = new System.Drawing.Point(8, 45);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(89, 21);
            this.Description.TabIndex = 1;
            this.Description.Text = "Description";
            // 
            // Street_Address_1
            // 
            this.Street_Address_1.AutoSize = true;
            this.Street_Address_1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Street_Address_1.Location = new System.Drawing.Point(8, 82);
            this.Street_Address_1.Name = "Street_Address_1";
            this.Street_Address_1.Size = new System.Drawing.Size(123, 21);
            this.Street_Address_1.TabIndex = 2;
            this.Street_Address_1.Text = "Street Address 1";
            // 
            // Street_Address_2
            // 
            this.Street_Address_2.AutoSize = true;
            this.Street_Address_2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Street_Address_2.Location = new System.Drawing.Point(8, 117);
            this.Street_Address_2.Name = "Street_Address_2";
            this.Street_Address_2.Size = new System.Drawing.Size(123, 21);
            this.Street_Address_2.TabIndex = 3;
            this.Street_Address_2.Text = "Street Address 2";
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.City.Location = new System.Drawing.Point(8, 154);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(37, 21);
            this.City.TabIndex = 4;
            this.City.Text = "City";
            // 
            // Province
            // 
            this.Province.AutoSize = true;
            this.Province.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Province.Location = new System.Drawing.Point(8, 191);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(70, 21);
            this.Province.TabIndex = 5;
            this.Province.Text = "Province";
            // 
            // Postal_Code
            // 
            this.Postal_Code.AutoSize = true;
            this.Postal_Code.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Postal_Code.Location = new System.Drawing.Point(8, 226);
            this.Postal_Code.Name = "Postal_Code";
            this.Postal_Code.Size = new System.Drawing.Size(91, 21);
            this.Postal_Code.TabIndex = 6;
            this.Postal_Code.Text = "Postal Code";
            // 
            // Phone_Num
            // 
            this.Phone_Num.AutoSize = true;
            this.Phone_Num.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Phone_Num.Location = new System.Drawing.Point(8, 260);
            this.Phone_Num.Name = "Phone_Num";
            this.Phone_Num.Size = new System.Drawing.Size(116, 21);
            this.Phone_Num.TabIndex = 7;
            this.Phone_Num.Text = "Phone Number";
            // 
            // Streetaddress1box
            // 
            this.Streetaddress1box.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Streetaddress1box.Location = new System.Drawing.Point(186, 84);
            this.Streetaddress1box.Name = "Streetaddress1box";
            this.Streetaddress1box.Size = new System.Drawing.Size(194, 23);
            this.Streetaddress1box.TabIndex = 8;
            // 
            // Streetaddress2box
            // 
            this.Streetaddress2box.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Streetaddress2box.Location = new System.Drawing.Point(186, 119);
            this.Streetaddress2box.Name = "Streetaddress2box";
            this.Streetaddress2box.Size = new System.Drawing.Size(194, 23);
            this.Streetaddress2box.TabIndex = 9;
            // 
            // postalCodebox
            // 
            this.postalCodebox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.postalCodebox.Location = new System.Drawing.Point(186, 224);
            this.postalCodebox.Name = "postalCodebox";
            this.postalCodebox.Size = new System.Drawing.Size(194, 23);
            this.postalCodebox.TabIndex = 10;
            // 
            // provincebox
            // 
            this.provincebox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.provincebox.Location = new System.Drawing.Point(186, 189);
            this.provincebox.Name = "provincebox";
            this.provincebox.Size = new System.Drawing.Size(194, 23);
            this.provincebox.TabIndex = 11;
            // 
            // Citybox
            // 
            this.Citybox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Citybox.Location = new System.Drawing.Point(186, 156);
            this.Citybox.Name = "Citybox";
            this.Citybox.Size = new System.Drawing.Size(194, 23);
            this.Citybox.TabIndex = 12;
            // 
            // phonenumberbox
            // 
            this.phonenumberbox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.phonenumberbox.Location = new System.Drawing.Point(186, 260);
            this.phonenumberbox.Name = "phonenumberbox";
            this.phonenumberbox.Size = new System.Drawing.Size(194, 23);
            this.phonenumberbox.TabIndex = 13;
            // 
            // Add_Branch
            // 
            this.Add_Branch.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Add_Branch.Location = new System.Drawing.Point(186, 289);
            this.Add_Branch.Name = "Add_Branch";
            this.Add_Branch.Size = new System.Drawing.Size(194, 38);
            this.Add_Branch.TabIndex = 14;
            this.Add_Branch.Text = "Add Branch";
            this.Add_Branch.UseVisualStyleBackColor = true;
            this.Add_Branch.Click += new System.EventHandler(this.Add_Branch_Click);
            // 
            // Modify_Branch
            // 
            this.Modify_Branch.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Modify_Branch.Location = new System.Drawing.Point(186, 333);
            this.Modify_Branch.Name = "Modify_Branch";
            this.Modify_Branch.Size = new System.Drawing.Size(194, 38);
            this.Modify_Branch.TabIndex = 15;
            this.Modify_Branch.Text = "Modify Branch";
            this.Modify_Branch.UseVisualStyleBackColor = true;
            this.Modify_Branch.Click += new System.EventHandler(this.Modify_Branch_Click);
            // 
            // Delete_Branch
            // 
            this.Delete_Branch.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Delete_Branch.Location = new System.Drawing.Point(186, 377);
            this.Delete_Branch.Name = "Delete_Branch";
            this.Delete_Branch.Size = new System.Drawing.Size(194, 38);
            this.Delete_Branch.TabIndex = 16;
            this.Delete_Branch.Text = "Delete Branch";
            this.Delete_Branch.UseVisualStyleBackColor = true;
            this.Delete_Branch.Click += new System.EventHandler(this.Delete_Branch_Click);
            // 
            // Descriptionbox
            // 
            this.Descriptionbox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Descriptionbox.Location = new System.Drawing.Point(186, 47);
            this.Descriptionbox.Name = "Descriptionbox";
            this.Descriptionbox.Size = new System.Drawing.Size(194, 23);
            this.Descriptionbox.TabIndex = 19;
            // 
            // BranchIDbox
            // 
            this.BranchIDbox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BranchIDbox.Location = new System.Drawing.Point(186, 13);
            this.BranchIDbox.Name = "BranchIDbox";
            this.BranchIDbox.Size = new System.Drawing.Size(194, 23);
            this.BranchIDbox.TabIndex = 20;
            this.BranchIDbox.TextChanged += new System.EventHandler(this.BranchIDbox_TextChanged);
            // 
            // display
            // 
            this.display.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.display.Location = new System.Drawing.Point(400, 12);
            this.display.Name = "display";
            this.display.RowTemplate.Height = 25;
            this.display.Size = new System.Drawing.Size(807, 403);
            this.display.TabIndex = 21;
            // 
            // branch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 430);
            this.Controls.Add(this.display);
            this.Controls.Add(this.BranchIDbox);
            this.Controls.Add(this.Descriptionbox);
            this.Controls.Add(this.Delete_Branch);
            this.Controls.Add(this.Modify_Branch);
            this.Controls.Add(this.Add_Branch);
            this.Controls.Add(this.phonenumberbox);
            this.Controls.Add(this.Citybox);
            this.Controls.Add(this.provincebox);
            this.Controls.Add(this.postalCodebox);
            this.Controls.Add(this.Streetaddress2box);
            this.Controls.Add(this.Streetaddress1box);
            this.Controls.Add(this.Phone_Num);
            this.Controls.Add(this.Postal_Code);
            this.Controls.Add(this.Province);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Street_Address_2);
            this.Controls.Add(this.Street_Address_1);
            this.Controls.Add(this.Description);
            this.Controls.Add(this.Branch_ID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "branch";
            this.Text = "Branch (Staff)";
            this.Load += new System.EventHandler(this.branch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.display)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Branch_ID;
        private Label Description;
        private Label Street_Address_1;
        private Label Street_Address_2;
        private Label City;
        private Label Province;
        private Label Postal_Code;
        private Label Phone_Num;
        private TextBox Streetaddress1box;
        private TextBox Streetaddress2box;
        private TextBox postalCodebox;
        private TextBox provincebox;
        private TextBox Citybox;
        private TextBox phonenumberbox;
        private Button Add_Branch;
        private Button Modify_Branch;
        private Button Delete_Branch;
        private TextBox Descriptionbox;
        private TextBox BranchIDbox;
        private DataGridView display;
    }
}
