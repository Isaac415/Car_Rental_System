﻿namespace Car_Rental_System
{
    partial class new_user
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.driving_license = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.date_of_birth = new System.Windows.Forms.DateTimePicker();
            this.insurance = new System.Windows.Forms.TextBox();
            this.phone_no = new System.Windows.Forms.TextBox();
            this.postal_code = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.province = new System.Windows.Forms.TextBox();
            this.street_add_2 = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.street_add_1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.last_name = new System.Windows.Forms.TextBox();
            this.first_name = new System.Windows.Forms.TextBox();
            this.middle_name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(9, 351);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 21);
            this.label14.TabIndex = 73;
            this.label14.Text = "Driving License";
            // 
            // driving_license
            // 
            this.driving_license.Location = new System.Drawing.Point(161, 351);
            this.driving_license.Name = "driving_license";
            this.driving_license.Size = new System.Drawing.Size(194, 23);
            this.driving_license.TabIndex = 71;
            // 
            // label11
            // 
            this.label11.AllowDrop = true;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(10, 322);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 21);
            this.label11.TabIndex = 70;
            this.label11.Text = "Insurance";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(10, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 21);
            this.label12.TabIndex = 69;
            this.label12.Text = "Phone No.";
            // 
            // date_of_birth
            // 
            this.date_of_birth.Location = new System.Drawing.Point(161, 262);
            this.date_of_birth.Name = "date_of_birth";
            this.date_of_birth.Size = new System.Drawing.Size(194, 23);
            this.date_of_birth.TabIndex = 68;
            // 
            // insurance
            // 
            this.insurance.Location = new System.Drawing.Point(161, 322);
            this.insurance.Name = "insurance";
            this.insurance.Size = new System.Drawing.Size(194, 23);
            this.insurance.TabIndex = 67;
            // 
            // phone_no
            // 
            this.phone_no.Location = new System.Drawing.Point(161, 291);
            this.phone_no.Name = "phone_no";
            this.phone_no.Size = new System.Drawing.Size(194, 23);
            this.phone_no.TabIndex = 66;
            // 
            // postal_code
            // 
            this.postal_code.Location = new System.Drawing.Point(161, 226);
            this.postal_code.Name = "postal_code";
            this.postal_code.Size = new System.Drawing.Size(194, 23);
            this.postal_code.TabIndex = 65;
            // 
            // label6
            // 
            this.label6.AllowDrop = true;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(10, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 21);
            this.label6.TabIndex = 64;
            this.label6.Text = "Date of Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(10, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 21);
            this.label7.TabIndex = 63;
            this.label7.Text = "Postal Code";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(10, 196);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 21);
            this.label8.TabIndex = 62;
            this.label8.Text = "Province";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(10, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 21);
            this.label9.TabIndex = 61;
            this.label9.Text = "City";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(10, 133);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 21);
            this.label10.TabIndex = 60;
            this.label10.Text = "Street Address 2";
            // 
            // province
            // 
            this.province.Location = new System.Drawing.Point(161, 196);
            this.province.Name = "province";
            this.province.Size = new System.Drawing.Size(194, 23);
            this.province.TabIndex = 59;
            // 
            // street_add_2
            // 
            this.street_add_2.Location = new System.Drawing.Point(161, 132);
            this.street_add_2.Name = "street_add_2";
            this.street_add_2.Size = new System.Drawing.Size(194, 23);
            this.street_add_2.TabIndex = 58;
            // 
            // city
            // 
            this.city.Location = new System.Drawing.Point(161, 165);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(194, 23);
            this.city.TabIndex = 57;
            // 
            // street_add_1
            // 
            this.street_add_1.Location = new System.Drawing.Point(161, 100);
            this.street_add_1.Name = "street_add_1";
            this.street_add_1.Size = new System.Drawing.Size(194, 23);
            this.street_add_1.TabIndex = 56;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(161, 380);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 38);
            this.button1.TabIndex = 55;
            this.button1.Text = "Register";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // last_name
            // 
            this.last_name.Location = new System.Drawing.Point(161, 71);
            this.last_name.Name = "last_name";
            this.last_name.Size = new System.Drawing.Size(194, 23);
            this.last_name.TabIndex = 54;
            // 
            // first_name
            // 
            this.first_name.Location = new System.Drawing.Point(161, 9);
            this.first_name.Name = "first_name";
            this.first_name.Size = new System.Drawing.Size(194, 23);
            this.first_name.TabIndex = 53;
            // 
            // middle_name
            // 
            this.middle_name.Location = new System.Drawing.Point(161, 42);
            this.middle_name.Name = "middle_name";
            this.middle_name.Size = new System.Drawing.Size(194, 23);
            this.middle_name.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(10, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 21);
            this.label5.TabIndex = 50;
            this.label5.Text = "Street Address 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(10, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 21);
            this.label4.TabIndex = 49;
            this.label4.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(10, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 21);
            this.label3.TabIndex = 48;
            this.label3.Text = "Middle Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(10, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 21);
            this.label2.TabIndex = 47;
            this.label2.Text = "First Name";
            // 
            // new_user
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 430);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.driving_license);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.date_of_birth);
            this.Controls.Add(this.insurance);
            this.Controls.Add(this.phone_no);
            this.Controls.Add(this.postal_code);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.province);
            this.Controls.Add(this.street_add_2);
            this.Controls.Add(this.city);
            this.Controls.Add(this.street_add_1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.last_name);
            this.Controls.Add(this.first_name);
            this.Controls.Add(this.middle_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "new_user";
            this.Text = "New User (User)";
            this.Load += new System.EventHandler(this.new_user_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label14;
        private TextBox driving_license;
        private Label label11;
        private Label label12;
        private DateTimePicker date_of_birth;
        private TextBox insurance;
        private TextBox phone_no;
        private TextBox postal_code;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox province;
        private TextBox street_add_2;
        private TextBox city;
        private TextBox street_add_1;
        private Button button1;
        private TextBox last_name;
        private TextBox first_name;
        private TextBox middle_name;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
    }
}